from youtube_transcript_api import YouTubeTranscriptApi
import json
import codecs
 
_id = "Iy5jVzW501M"
transcript = YouTubeTranscriptApi.get_transcript(_id, languages=['ar'])
with codecs.open("trans.json", "w", "ISO-8859-1") as json_file:
            json.dump(transcript, json_file)
